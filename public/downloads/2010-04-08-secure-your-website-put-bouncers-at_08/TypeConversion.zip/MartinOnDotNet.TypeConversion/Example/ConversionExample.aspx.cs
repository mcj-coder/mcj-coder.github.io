﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Globalization;

namespace MartinOnDotNet.TypeConversion.Example
{
    /// <summary>
    /// This page demonstrates using the Convert class to parse a querystring value
    /// </summary>
    public partial class ConversionExample : System.Web.UI.Page
    {

        #region Different Conversion Methods

        /// <summary>
        /// Converts the given string to an integer
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        private static int ConvertToInteger(string value)
        {
            int id = 0;
            try
            {
                id = Convert.ToInt32(value);
            }
            catch (FormatException fex)
            {
                throw new NotSupportedException(string.Format(CultureInfo.InvariantCulture, "The value should be an integer but the value given was '{0}'", value), fex);
            }
            return id;
        }

        /// <summary>
        /// Parses the given string to an integer
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        private static int ParseToInteger(string value)
        {
            int id = 0;
            try
            {
                id = Int32.Parse(value);
            }
            catch (FormatException fex)
            {
                throw new NotSupportedException(string.Format(CultureInfo.InvariantCulture, "The value should be an integer but the value given was '{0}'", value), fex);
            }
            return id;
        }

        /// <summary>
        /// Parses the given string to an integer using the TryParse method
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        private static int TryParseToInteger(string value)
        {
            int id = 0;
            if (!Int32.TryParse(value, out id)) id = 0;
            return id;
        }

        /// <summary>
        /// Parses the given string to an integer using the TryParse method using the Utility Extensions
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        private static int TryParseToIntegerViaExtension(string value)
        {
            return value.ToInt(0);
        }

        #endregion

        private delegate int ParseValueAsInteger(string value);

        private ParseValueAsInteger _conversionMethod;

        /// <summary>
        /// Handles the Load event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_Load(object sender, EventArgs e)
        {
            _conversionMethod = new ParseValueAsInteger(TryParseToIntegerViaExtension);
        }

        /// <summary>
        /// Handles the OnPreRender event of the Page control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void Page_PreRender(object sender, EventArgs e)
        {
            string value = Request.QueryString["id"];
            int id = _conversionMethod(value);
            //if (id <= 0) throw new ArgumentOutOfRangeException(string.Format(CultureInfo.InvariantCulture, "The querystring parameter 'id' should be a positive integer, value given was '{0}'", value)); ;

            this.ResultLabel.Text = id.ToString();

            long timing = PerformRepeats("12345");
            SuccessLabel.Text = timing.ToString();

            timing = PerformRepeats("Not A String");
            FailureLabel.Text = timing.ToString();
        }

        private long PerformRepeats(string value)
        {
            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
            sw.Start();
            for (int i = 0; i < Properties.Settings.Default.NumberOfRepeats; i++)
            {
                try
                {
                    int id = _conversionMethod(value);
                }
                catch
                {
                    //swallow for timing purposes
                }
            }
            sw.Stop();
            return sw.ElapsedMilliseconds;
        }

        /// <summary>
        /// Gets the number of repeats.
        /// </summary>
        /// <value>The number of repeats.</value>
        protected long NumberOfRepeats
        {
            get
            {
                return Properties.Settings.Default.NumberOfRepeats;
            }
        }

        /// <summary>
        /// Called when a change method button is clicked
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        protected void OnChangeMethod(object sender, EventArgs e)
        {
            Button cm = sender as Button;
            CurrentMethodLabel.Text=cm.CommandArgument;
            if (cm == ConvertButton)
            {
                _conversionMethod = new ParseValueAsInteger(ConvertToInteger);
            }
            else if (cm==ParseButton)
            {
                _conversionMethod = new ParseValueAsInteger(ParseToInteger);
            }
            else if (cm == TryParseButton)
            {
                _conversionMethod = new ParseValueAsInteger(TryParseToInteger);
            }
        }
    }
}
