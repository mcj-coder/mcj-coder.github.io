﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace MartinOnDotNet.TypeConversion
{

    public static partial class Utility
    {
        /// <summary>
        /// Resolves the culture for currency.
        /// </summary>
        /// <param name="currencyCode">The currency ISO code.</param>
        /// <returns>The first Culture Info object that uses the given currency</returns>
        public static CultureInfo ToCultureInfoForCurrency(this string currencyCode)
        {
            if (string.IsNullOrEmpty(currencyCode)) throw new ArgumentNullException("currencyCode");
            foreach (CultureInfo ci in CultureInfo.GetCultures(CultureTypes.SpecificCultures))
            {
                RegionInfo ri = new RegionInfo(ci.LCID);
                if (string.Equals(currencyCode, ri.ISOCurrencySymbol, StringComparison.OrdinalIgnoreCase)) return ci;
            }
            throw new NotSupportedException(string.Format(CultureInfo.InvariantCulture, "There is no CultureInfo available for '{0}'", currencyCode));
        }

        /// <summary>
        /// Toes the culture info.
        /// </summary>
        /// <param name="languageCode">The language code.</param>
        /// <returns>
        /// The culture object represented by the langauge code
        /// </returns>
        public static CultureInfo ToCultureInfo(this string languageCode)
        {
            int localeLcid = languageCode.ToInt(-1);
            if (localeLcid == -1) return new CultureInfo(languageCode);
            return new CultureInfo(localeLcid);
        }
    }
}
