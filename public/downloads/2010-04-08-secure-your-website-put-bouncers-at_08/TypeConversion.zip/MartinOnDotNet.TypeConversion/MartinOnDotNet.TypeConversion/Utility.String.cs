﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;

namespace MartinOnDotNet.TypeConversion
{
    public static partial class Utility
    {
        /// <summary>
        /// The characters that are used to split lists
        /// </summary>
        private static readonly char[] DefaultListDelimiters = new char[] { ',', ';' };

        /// <summary>
        /// Gets the list.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>A list of strings within the given value</returns>
        public static IList<string> ToList(this string value)
        {
            return value.ToList(DefaultListDelimiters);
        }

        /// <summary>
        /// Gets the list.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="delimiters">The delimiters.</param>
        /// <returns>A list of strings within the given value</returns>
        public static IList<string> ToList(this string value, char[] delimiters)
        {
            if (delimiters == null || delimiters.Length == 0) throw new ArgumentException("You must provide as least one delimiter", "delimiters");
            List<string> list = new List<string>();
            if (!string.IsNullOrEmpty(value))
            {
                string[] idlist = value.Split(delimiters, StringSplitOptions.RemoveEmptyEntries);
                if (idlist != null) list.AddRange(idlist);
            }
            return list.AsReadOnly();
        }

        /// <summary>
        /// Url encodes the given string and escapes any ' or " characters
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static string ToXssSafeString(this string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            char[] xssCharacters = new char[] { '\'', '\"' };
            if (value.IndexOfAny(xssCharacters) > -1)
            {
                foreach (char c in xssCharacters)
                {
                    value = value.Replace(c.ToString(), "\\" + c.ToString());
                }
            }
            return System.Web.HttpUtility.HtmlEncode(value);
        }

        /// <summary>
        /// Converts the Enumerable collection to a delimited string.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list">The list.</param>
        /// <param name="delimiter">The delimiter.</param>
        /// <returns>A string delimiting the items in the list use invariant standard string formatting</returns>
        public static string ToDelimitedString<T>(this IEnumerable<T> list, string delimiter)
        {
            return ToDelimitedString<T>(list, delimiter, System.Globalization.CultureInfo.InvariantCulture, string.Empty);
        }

        /// <summary>
        /// Converts the Enumerable collection to a delimited string.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="list">The list.</param>
        /// <param name="delimiter">The delimiter.</param>
        /// <param name="formatter">The formatter.</param>
        /// <param name="format">The format.</param>
        /// <returns>A string delimiting the items in the list using the provided formatting options</returns>
        public static string ToDelimitedString<T>(this IEnumerable<T> list, string delimiter, IFormatProvider formatter, string format)
        {
            if (list == null) return string.Empty;
            List<string> strings = new List<string>();
            string formatToUse = "{0}";
            if (!string.IsNullOrEmpty(format)) formatToUse = string.Concat("{0:", format, "}");
            foreach (T item in list)
            {
                strings.Add(string.Format(formatter, formatToUse, item));
            }
            return string.Join(delimiter, strings.ToArray());
        }
    }
}
