﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Globalization;
using System.IO;

namespace MartinOnDotNet.TypeConversion
{
    public static partial class Utility
    {
        /// <summary>
        /// Converts the generic type to a readable string
        /// </summary>
        /// <param name="type">The type.</param>
        /// <returns>The readable type name as a string</returns>
        public static string ToReadableString(this Type type)
        {
            if (type == null) throw new ArgumentNullException("type");
            if (type.IsGenericType)
            {
                CodeDomProvider csharpProvider = CodeDomProvider.CreateProvider("C#");
                CodeTypeReference typeReference = new CodeTypeReference(type);
                CodeTypeReferenceExpression variableDeclaration = new CodeTypeReferenceExpression(typeReference);
                StringBuilder sb = new StringBuilder();
                using (StringWriter writer = new StringWriter(sb, CultureInfo.InvariantCulture))
                {
                    csharpProvider.GenerateCodeFromExpression(variableDeclaration, writer, new CodeGeneratorOptions());
                }

                return sb.ToString();
            }
            else
            {
               return type.FullName;
            }
        }
    }
}
