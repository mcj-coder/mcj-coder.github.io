﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;

namespace MartinOnDotNet.TypeConversion
{

    public static partial class Utility
    {
        /// <summary>
        /// Gets the Boolean value stored in the string
        /// </summary>
        /// <param name="value">The string to parse</param>
        /// <returns>The setting stored in the brand/locale specific resource file or <c>null</c> if the value cannot be converted</returns>
        public static Boolean? ToBoolean(this string value)
        {
            if (string.IsNullOrEmpty(value)) return null;
            Boolean? result = null;
            Boolean temp;
            if (Boolean.TryParse(value, out temp)) result = temp;
            return result;
        }

        /// <summary>
        /// Gets the Boolean value stored in the string
        /// </summary>
        /// <param name="value">The string to parse</param>
        /// <param name="defaultValue">The default value if the the given value cannot be parsed</param>
        /// <returns>The setting stored in the brand/locale specific resource file or <c>null</c> if the value cannot be converted</returns>
        public static Boolean ToBoolean(this string value, Boolean defaultValue)
        {
            if (string.IsNullOrEmpty(value)) return defaultValue;
            Boolean? result = null;
            Boolean temp;
            if (Boolean.TryParse(value, out temp)) result = temp;
            return result ?? defaultValue;
        }

        /// <summary>
        /// Converts the Enumerable collection to a delimited string.
        /// </summary>
        /// <param name="list">The list.</param>
        /// <param name="delimiter">The delimiter.</param>
        /// <returns>
        /// A string delimiting the items in the list use invariant standard string formatting
        /// </returns>
        public static string ToDelimitedString(this IEnumerable<Boolean> list, string delimiter)
        {
            return ToDelimitedString<Boolean>(list, delimiter, System.Globalization.CultureInfo.InvariantCulture, string.Empty);
        }

        /// <summary>
        /// Converts the Enumerable collection to a delimited string.
        /// </summary>
        /// <param name="list">The list.</param>
        /// <param name="delimiter">The delimiter.</param>
        /// <param name="formatter">The formatter.</param>
        /// <param name="format">The format.</param>
        /// <returns>
        /// A string delimiting the items in the list using the provided formatting options
        /// </returns>
        public static string ToDelimitedString(this IEnumerable<Boolean> list, string delimiter, IFormatProvider formatter, string format)
        {
            return ToDelimitedString<Boolean>(list, delimiter, formatter, format);
        }
    }
}
