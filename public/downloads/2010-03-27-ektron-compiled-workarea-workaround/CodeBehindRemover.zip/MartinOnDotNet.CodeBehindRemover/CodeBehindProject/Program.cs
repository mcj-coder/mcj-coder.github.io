﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using System.Globalization;

namespace MartinOnDotNet.CodeBehindRemover
{
    /// <summary>
    /// Codebehind Remover Utility App for allowing Web Application Projects to exist within a Web Site project
    /// </summary>
    public sealed class Program
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Program"/> class.
        /// </summary>
        private Program() { }

        /// <summary>
        /// Regex to match the codebehind (or codefile) attribute in ui file.
        /// </summary>
        private static string codeBehindRegex = @"\sCode(behind|file)\s?=\s?([""'])[^""']+(\2)";

        private static Regex _regex = new Regex(codeBehindRegex, RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Singleline);

        static Arguments _args;

        /// <summary>
        /// Gets the args.
        /// </summary>
        /// <value>The args.</value>
        public static Arguments Args
        {
            get { return _args; }
        }

        /// <summary>
        /// Main program method
        /// </summary>
        /// <param name="args">The args.</param>
        public static void Main(string[] args)
        {
            _args = new Arguments(args);
            System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();
            if (ArgumentsAreValid)
            {
                string input = Args["i"];
                string output = Args["o"];
                string extensions = Args["e"];

                bool skipUnmodifiedFiles = true;
                if (!bool.TryParse(Args["s"], out skipUnmodifiedFiles)) skipUnmodifiedFiles = true;
                if (string.IsNullOrEmpty(extensions)) extensions = "ascx,aspx,master,asmx,ashx";
                RemoveCodeBehindAttribute(input, output, extensions, skipUnmodifiedFiles);
            }
            else
            {
                Console.WriteLine("You must provide an input file/folder and an output file/folder");
                Console.WriteLine(string.Format(CultureInfo.InvariantCulture,"{0} /i=<Input Folder> /o=<Output Folder>", System.Reflection.Assembly.GetCallingAssembly().FullName));
            }
            sw.Stop();
            Console.WriteLine(string.Format(CultureInfo.InvariantCulture, "Total Execution Time: {0}ms", sw.ElapsedMilliseconds));
        }

        /// <summary>
        /// Removes the code behind attribute.
        /// </summary>
        /// <param name="input">The input file or folder.</param>
        /// <param name="output">The output file or folder.</param>
        /// <param name="extensions">The extensions.</param>
        /// <param name="skipUnmodifiedFiles">if set to <c>true</c> skip unmodified files.</param>
        private static void RemoveCodeBehindAttribute(string input, string output, string extensions, bool skipUnmodifiedFiles)
        {
            if (Directory.Exists(input) && Directory.Exists(output))
            {
                List<string> files = GatherFilesToProcess(input, extensions);
                foreach (string filepath in files)
                {
                    string relative = filepath.Replace(input, string.Empty).TrimStart(new char[] { '/', '\\' });
                    ProcessFile(filepath, Path.Combine(output, relative), skipUnmodifiedFiles);
                }
            }
            else if (File.Exists(input))
            {
                ProcessFile(input, output, skipUnmodifiedFiles);
            }
        }

        /// <summary>
        /// Gathers the files to process.
        /// </summary>
        /// <param name="input">The input.</param>
        /// <param name="extensions">The extensions.</param>
        /// <returns></returns>
        private static List<string> GatherFilesToProcess(string input, string extensions)
        {
            string[] exts = extensions.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            List<string> files = new List<string>();
            foreach (string s in exts)
            {
                files.AddRange(Directory.GetFiles(input, string.Concat("*.", s), SearchOption.AllDirectories));
            }
            return files;
        }

        /// <summary>
        /// Processes the file.
        /// </summary>
        /// <param name="inputFile">The input file.</param>
        /// <param name="outputFile">The output file.</param>
        /// <param name="skipIfNotNeeded">if set to <c>true</c> unmodified files will be skipped.</param>
        private static void ProcessFile(string inputFile, string outputFile, bool skipIfNotNeeded)
        {
            Console.Write(string.Format(CultureInfo.InvariantCulture, "{0}...", inputFile));
            if (skipIfNotNeeded && !HasInputFileBeenUpdated(inputFile, outputFile))
            {
                Console.WriteLine("Skipped");
                return;
            }
            string outputPath = new FileInfo(outputFile).Directory.FullName;
            if (!Directory.Exists(outputPath)) Directory.CreateDirectory(outputPath);
            string content;
            using (StreamReader sr = new StreamReader(inputFile))
            {
                content = sr.ReadToEnd();
            }
            string newContent = _regex.Replace(content, string.Empty);
            if (File.Exists(outputFile))
            {
                FileAttributes fa = File.GetAttributes(outputFile);
                fa &= ~FileAttributes.ReadOnly;
                File.SetAttributes(outputFile, fa);
            }
            using (StreamWriter sw = new StreamWriter(outputFile, false))
            {
                sw.Write(newContent);
            }
            Console.WriteLine("Done");
        }

        /// <summary>
        /// Determines whether the input file has been updated since the output files last modification
        /// </summary>
        /// <param name="inputFile">The input file.</param>
        /// <param name="outputFile">The output file.</param>
        /// <returns>
        /// 	<c>true</c> if the input file has been updated otherwise, <c>false</c>.
        /// </returns>
        private static bool HasInputFileBeenUpdated(string inputFile, string outputFile)
        {
            if (File.Exists(inputFile) && File.Exists(outputFile))
            {
                FileInfo input = new FileInfo(inputFile);
                FileInfo output = new FileInfo(outputFile);
                return (input.LastWriteTime >= output.LastWriteTime);
            }
            return true;
        }

        /// <summary>
        /// Gets a value indicating whether the required command line arguments are valid
        /// </summary>
        /// <value><c>true</c> if arguments are valid; otherwise, <c>false</c>.</value>
        private static bool ArgumentsAreValid
        {
            get
            {
                return (!string.IsNullOrEmpty(Args["i"]) && !string.IsNullOrEmpty(Args["o"]));
            }
        }
    }
}
