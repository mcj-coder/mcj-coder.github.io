﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Xml.Linq;
using MbUnit.Framework;

namespace MartinOnDotNet.VerificationTests
{
    /// <summary>
    /// Includes methods to verify the validity of a sitemap.xml
    /// </summary>
    public sealed class ValidateSiteMap
    {

        /// <summary>
        /// Generates a static test for each url referenced within the sitemap
        /// </summary>
        [StaticTestFactory, Parallelizable(TestScope.Descendants)]
        public static IEnumerable<Test> GenerateSiteMapLinkTests()
        {
            Uri sitemapUri = new Uri(Properties.Settings.Default.SiteMapXmlUri); // Uri for Xml Sitemap to test : http://localhost/sitemap.xml
            int requestTimeout = Properties.Settings.Default.SiteMapRequestTimeout; //timeout for each request in ms : 300ms

            IEnumerable<string> locations = GetSitemapLocations(sitemapUri);
            //is sitemap populated
            yield return CreateSitemapHasNodesTest(sitemapUri, locations);
            
            //are all reference urls valid
            foreach (string location in locations)
            {
                yield return CreateLocationTest(requestTimeout, location, HttpStatusCode.OK);
            }
            
            // check that robots.txt is present
            Uri robotstxtUri = new Uri(sitemapUri, "/robots.txt");
            yield return CreateLocationTest(requestTimeout, robotstxtUri.ToString(), HttpStatusCode.OK);
            //finally, let's check that a deliberately incorrect url
            Uri nonExistantUri = new Uri(sitemapUri, "/nonexistantfileonserver/");
            yield return CreateLocationTest(requestTimeout, nonExistantUri.ToString(), HttpStatusCode.NotFound);
            
        }

        /// <summary>
        /// Creates the sitemap has nodes test.
        /// </summary>
        /// <param name="sitemapUri">The sitemap URI.</param>
        /// <param name="locations">The locations.</param>
        /// <returns>A test that checks the sitemap has nodes</returns>
        private static TestCase CreateSitemapHasNodesTest(Uri sitemapUri, IEnumerable<string> locations)
        {
            return new TestCase(string.Format(CultureInfo.InvariantCulture, "{0} - Sitemap Has Entries", sitemapUri), () =>
            {
                Assert.IsTrue(locations.Any());
            });
        }

        /// <summary>
        /// Creates the location test.
        /// </summary>
        /// <param name="requestTimeout">The request timeout.</param>
        /// <param name="location">The location.</param>
        /// <returns>A unique test for a sitemap location</returns>
        private static TestCase CreateLocationTest(int requestTimeout, string location, HttpStatusCode expectedResult)
        {
            return new TestCase(location, () =>
            {
                HttpWebRequest wrq = HttpWebRequest.Create(location) as HttpWebRequest;
                wrq.UserAgent = "Googlebot/2.1 (+http://www.google.com/bot.html)"; // appear to be google to escape any custom error handling
                wrq.Timeout = requestTimeout;
                HttpWebResponse wrp = null;
                try
                {
                    wrp = GetResponse(wrq);
                    Assert.AreEqual<System.Net.HttpStatusCode>(expectedResult, wrp.StatusCode);
                }
                finally
                {
                    if (wrp != null) wrp.Close();
                }
            });
        }

        #region Helper Methods

        /// <summary>
        /// Gets the sitemap locations.
        /// </summary>
        /// <param name="sitemapUri">The sitemap URI.</param>
        /// <returns>A list of locations referenced within the sitemap</returns>
        private static IEnumerable<string> GetSitemapLocations(Uri sitemapUri)
        {
            XNamespace xn = XNamespace.Get(@"http://www.sitemaps.org/schemas/sitemap/0.9");
            XDocument xdoc = XDocument.Load(sitemapUri.ToString(), LoadOptions.PreserveWhitespace);
            return from loc in xdoc.Descendants(xn + "loc")
                            select loc.Value;
        }
   
        /// <summary>
        /// Gets the response object and handles any protocol exceptions
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns>The response object if available</returns>
        private static HttpWebResponse GetResponse(HttpWebRequest request)
        {
            try
            {
                return request.GetResponse() as HttpWebResponse;
            }
            catch (WebException wex)
            {
                if (wex.Status == WebExceptionStatus.ProtocolError)
                {
                    return wex.Response as HttpWebResponse;
                }
                else
                {
                    throw;
                }
            }
        }

        #endregion

    }
}
