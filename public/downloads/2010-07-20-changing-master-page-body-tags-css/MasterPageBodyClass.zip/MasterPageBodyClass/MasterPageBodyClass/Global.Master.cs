﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace MartinOnDotNet.MasterPageBodyClass
{
    public partial class Global : System.Web.UI.MasterPage
    {
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            BasePage current = Page as BasePage;
            if (current != null && !string.IsNullOrEmpty(current.BodyCssClass))
            {
                Body.Attributes["class"] = current.BodyCssClass;
            }
        }
    }
}
