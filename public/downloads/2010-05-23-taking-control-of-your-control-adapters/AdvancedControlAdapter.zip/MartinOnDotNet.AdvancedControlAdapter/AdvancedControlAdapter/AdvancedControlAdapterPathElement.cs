﻿using System;
using System.Collections;
using System.Text;
using System.Configuration;
using System.Xml;

namespace MartinOnDotNet.ControlAdapters
{

    /// <summary>
    /// Defines a new collection of ControlAdapter settings for a given path
    /// </summary>
    [Serializable]
    public class AdvancedControlAdapterPathElement : ConfigurationElement
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AdvancedControlAdapterPathElement"/> class.
        /// </summary>
        public AdvancedControlAdapterPathElement()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AdvancedControlAdapterPathElement"/> class.
        /// </summary>
        /// <param name="path">The path.</param>
        public AdvancedControlAdapterPathElement(string path)
        {
            Path = path;
        }


        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [ConfigurationProperty("path", DefaultValue = "", IsKey = true, IsRequired = true)]
        public string Path
        {
            get
            {
                return this["path"] as string;
            }
            set
            {
                this["path"] = value;
            }
        }
                  

        /// <summary>
        /// Gets or sets the whiteList Control Adapters
        /// </summary>
        /// <value>The whitelist registrations.</value>
        [ConfigurationProperty("whitelist", IsRequired = false)]
        [ConfigurationCollection(typeof(AdvancedControlAdapterRegistrationElement)
            , AddItemName = "add", RemoveItemName = "remove", ClearItemsName = "clear")]
        public AdvancedControlAdapterRegistrationCollection Whitelist
        {
            get
            {
                return this["whitelist"] as AdvancedControlAdapterRegistrationCollection;
            }

        }

        /// <summary>
        /// Gets or sets the black List Control Adapters
        /// </summary>
        /// <value>The black list registrations.</value>
        [ConfigurationProperty("blacklist", IsRequired = false)]
        [ConfigurationCollection(typeof(AdvancedControlAdapterRegistrationElement)
            , AddItemName = "add", RemoveItemName = "remove", ClearItemsName = "clear")]
        public AdvancedControlAdapterRegistrationCollection Blacklist
        {
            get
            {
                return this["blacklist"] as AdvancedControlAdapterRegistrationCollection;
            }

        }

        /// <summary>
        /// Gets or sets the injection Control Adapters
        /// </summary>
        /// <value>The injection registrations.</value>
        [ConfigurationProperty("injections", IsRequired = false)]
        [ConfigurationCollection(typeof(AdvancedControlAdapterRegistrationElement)
            , AddItemName = "add", RemoveItemName = "remove", ClearItemsName = "clear")]
        public AdvancedControlAdapterRegistrationCollection Injections
        {
            get
            {
                return this["injections"] as AdvancedControlAdapterRegistrationCollection;
            }

        }
    }
}