﻿using System;
using System.Collections;
using System.Text;
using System.Configuration;
using System.Xml;

namespace MartinOnDotNet.ControlAdapters
{

    /// <summary>
    /// Defines a new Control Adapter Registratio
    /// </summary>
    [Serializable]
    public class AdvancedControlAdapterRegistrationElement : ConfigurationElement
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="AdvancedControlAdapterRegistrationElement"/> class.
        /// </summary>
        public AdvancedControlAdapterRegistrationElement()
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="AdvancedControlAdapterRegistrationElement"/> class.
        /// </summary>
        /// <param name="controlAdapterType">Type of the control adapter.</param>
        public AdvancedControlAdapterRegistrationElement(string controlAdapterType)
        {
            ControlAdapterType = controlAdapterType;
        }
        
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        [ConfigurationProperty("controlAdapterType", DefaultValue = "", IsKey = true, IsRequired = false)]
        public string ControlAdapterType
        {
            get
            {
                return this["controlAdapterType"] as string;
            }
            set
            {
                this["controlAdapterType"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the type of the target control.
        /// </summary>
        /// <value>The type of the target control.</value>
        [ConfigurationProperty("targetControlType", DefaultValue = "", IsKey = false, IsRequired = false)]
        public string TargetControlType
        {
            get
            {
                return this["targetControlType"] as string;
            }
            set
            {
                this["targetControlType"] = value;
            }
        }

        /// <summary>
        /// Gets or sets the target control id.
        /// </summary>
        /// <value>The target control id.</value>
        [ConfigurationProperty("targetControlId", DefaultValue = "", IsKey = true, IsRequired = false)]
        public string TargetControlId
        {
            get
            {
                return this["targetControlId"] as string;
            }
            set
            {
                this["targetControlId"] = value;
            }
        }
        
    }
}