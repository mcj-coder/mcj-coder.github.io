﻿using System.Collections.Generic;
using System.Web.UI;

namespace MartinOnDotNet
{
    /// <summary>
    /// Useful extension methods for Controls
    /// </summary>
    public static class ControlExtensions
    {
        /// <summary>
        /// Recursively searches the control tree for all child controls of the given type
        /// </summary>
        /// <typeparam name="T">The type of control that your want to find</typeparam>
        /// <param name="parent">The parent control to begin searching from</param>
        /// <returns>A list of all child controls of the required type</returns>
        public static IEnumerable<T> GetAllChildControlsOfType<T>(this Control parent) where T : Control
        {
            List<T> children = new List<T>();
            foreach (Control c in parent.Controls)
            {
                if (typeof(T).IsInstanceOfType(c)) children.Add((T)c);
                if (c.Controls.Count > 0) children.AddRange(c.GetAllChildControlsOfType<T>());
            }
            return children.AsReadOnly();
        }

    }
}
