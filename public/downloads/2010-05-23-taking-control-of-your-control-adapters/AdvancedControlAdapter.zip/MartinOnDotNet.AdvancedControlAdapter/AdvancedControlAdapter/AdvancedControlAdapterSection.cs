﻿using System;
using System.Collections;
using System.Text;
using System.Configuration;
using System.Xml;

namespace MartinOnDotNet.ControlAdapters
{
    /// <summary>
    /// Allows the configuration of the <see ref="AdvancedControlAdapterModule" />
    /// </summary>
    public class AdvancedControlAdapterSection : ConfigurationSection
    {
        /// <summary>
        /// Gets or sets the path configurations that are configured in the config file
        /// </summary>
        /// <value>The path.</value>
        [ConfigurationProperty("paths", IsRequired = true)]
        [ConfigurationCollection(typeof(AdvancedControlAdapterPathCollection)
            , AddItemName = "add", RemoveItemName = "remove", ClearItemsName = "clear")]
        public AdvancedControlAdapterPathCollection Paths
        {
            get
            {
                return this["paths"] as AdvancedControlAdapterPathCollection;
            }
        }
    }
}
