﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.Adapters;
using MartinOnDotNet;
using System.Reflection;
using System.Text.RegularExpressions;

namespace MartinOnDotNet.ControlAdapters
{
    /// <summary>
    /// Allows the disabling and injection of control adapters based on url path
    /// </summary>
    public class AdvancedControlAdapterModule:IHttpModule 
    {

        /// <summary>
        /// Control Adapter Configuration Loaded from web.config
        /// </summary>
        private static AdvancedControlAdapterSection ControlAdapterConfig = 
            System.Configuration.ConfigurationManager.GetSection("controlAdapters") as AdvancedControlAdapterSection;

        /// <summary>
        /// Initializes a module and prepares it to handle requests.
        /// </summary>
        /// <param name="context">An <see cref="T:System.Web.HttpApplication"/> that provides access to the methods, properties, and events common to all application objects within an ASP.NET application</param>
        public void Init(HttpApplication context)
        {
            if (ControlAdapterConfig==null) return;
            context.PreRequestHandlerExecute += new EventHandler(OnPreRequestHandlerExecute);
        }

      
        private void OnPreRequestHandlerExecute(object sender, EventArgs e)
        {

            HttpContext current = HttpContext.Current;
            Page page = current.CurrentHandler as Page;
            if (page != null)
            {
                page.PreRenderComplete += new EventHandler(OnPreRenderComplete);
            }
        }


        private void OnPreRenderComplete(object sender, EventArgs e)
        {
            Page page = sender as Page;
            AdvancedControlAdapterPathElement path = GetPathConfigurationForRequest(page);
            if (path == null) return;
            if (path.Blacklist.Count > 0 || path.Whitelist.Count > 0) ProcessControlAdapters(page, path);
            if (path.Injections.Count > 0) InjectControlAdapters(page, path);
        }

        private static void InjectControlAdapters(Page page, AdvancedControlAdapterPathElement path)
        {
            PropertyInfo pi = typeof(Control).GetProperty("Adapter", BindingFlags.NonPublic | BindingFlags.Instance);
            FieldInfo fi = typeof(Control).GetField("_adapter", BindingFlags.NonPublic | BindingFlags.Instance);
            FieldInfo fiControl = typeof(ControlAdapter).GetField("_control", BindingFlags.NonPublic | BindingFlags.Instance);
            foreach (AdvancedControlAdapterRegistrationElement inject in path.Injections)
            {
                foreach (Control c in page.GetAllChildControlsOfType<Control>())
                {
                    if (
                        (
                            string.IsNullOrEmpty(inject.TargetControlType)
                            ||
                            string.Equals(c.GetType().FullName, inject.TargetControlType, StringComparison.OrdinalIgnoreCase)
                            ||
                            string.Equals(c.GetType().Name, inject.TargetControlType, StringComparison.OrdinalIgnoreCase)
                         )
                        &&
                            Regex.IsMatch(c.ClientID, inject.TargetControlId, RegexOptions.CultureInvariant | RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace)
                        )
                    {
                        ControlAdapter ca = pi.GetValue(c, null) as ControlAdapter; //bait ...
                        Type t = Type.GetType(inject.ControlAdapterType);
                        ControlAdapter injectCa = t.GetConstructor(Type.EmptyTypes).Invoke(null) as ControlAdapter;
                        fiControl.SetValue(injectCa, c);
                        fi.SetValue(c, injectCa);// ...and switch
                    }
                }
            }
        }

        private static void ProcessControlAdapters(Page page, AdvancedControlAdapterPathElement path)
        {
            PropertyInfo pi = typeof(Control).GetProperty("Adapter", BindingFlags.NonPublic | BindingFlags.Instance);
            FieldInfo fi = typeof(Control).GetField("_adapter", BindingFlags.NonPublic | BindingFlags.Instance);
            foreach (Control c in page.GetAllChildControlsOfType<Control>())
            {
                ControlAdapter ca = pi.GetValue(c, null) as ControlAdapter; // resolve Control Adapter
                if (ca != null)
                {
                    bool allowed = IsControlAdapterAllowed(path, ca.GetType());
                    if (!allowed) fi.SetValue(c, null); // disable
                }
            }
        }

        private static bool IsControlAdapterAllowed(AdvancedControlAdapterPathElement path, Type adapterType)
        {
            foreach (AdvancedControlAdapterRegistrationElement blacklisted in path.Blacklist)
            {
                if (
                        string.Equals(adapterType.FullName, blacklisted.ControlAdapterType, StringComparison.OrdinalIgnoreCase)
                        ||
                        string.Equals(adapterType.Name, blacklisted.ControlAdapterType, StringComparison.OrdinalIgnoreCase)
                    )
                {
                    return false; //not allowed
                }
            }
            return path.Whitelist.Count > 0 && (path.Whitelist[adapterType.FullName] != null || path.Whitelist[adapterType.Name] != null);
        }

        private static AdvancedControlAdapterPathElement GetPathConfigurationForRequest(Page page)
        {
            foreach (AdvancedControlAdapterPathElement acape in ControlAdapterConfig.Paths)
            {
                if (page.Request.Url.PathAndQuery.StartsWith(page.ResolveUrl(acape.Path), StringComparison.OrdinalIgnoreCase))
                {
                    return acape;
                }
            }
            return null;
        }

        /// <summary>
        /// Disposes of the resources (other than memory) used by the module that implements <see cref="T:System.Web.IHttpModule"/>.
        /// </summary>
        public void Dispose()
        {

        }
    }
}
