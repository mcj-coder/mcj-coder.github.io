﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Globalization;

namespace MartinOnDotNet.BasicControlAdapter
{
    /// <summary>
    /// Checkbox Control Adapter to remove unneeded flow markup
    /// </summary>
    public class CheckBoxControlAdapter : System.Web.UI.Adapters.ControlAdapter
    {


        /// <summary>
        /// Generates the target-specific markup for the control to which the control adapter is attached.
        /// </summary>
        /// <param name="writer">The <see cref="T:System.Web.UI.HtmlTextWriter"/> to use to render the target-specific output.</param>
        protected override void Render(HtmlTextWriter writer)
        {
            CheckBox cb = this.Control as CheckBox;
            if (cb != null)
            {
                if (cb.TextAlign == TextAlign.Left) RenderLabel(writer, cb.ClientID, cb.Text, cb.CssClass);
                if (!string.IsNullOrEmpty(cb.CssClass)) writer.AddAttribute(HtmlTextWriterAttribute.Class, cb.CssClass);
                if (cb.TabIndex > 0) writer.AddAttribute(HtmlTextWriterAttribute.Tabindex, cb.TabIndex.ToString(CultureInfo.InvariantCulture));
                if (!string.IsNullOrEmpty(cb.ToolTip)) writer.AddAttribute(HtmlTextWriterAttribute.Title, cb.ToolTip);
                writer.AddAttribute(HtmlTextWriterAttribute.Id, cb.ClientID);
                writer.AddAttribute(HtmlTextWriterAttribute.Name, cb.UniqueID);
                writer.AddAttribute(HtmlTextWriterAttribute.Type, "checkbox");
                writer.RenderBeginTag(HtmlTextWriterTag.Input);
                writer.RenderEndTag();
                if (cb.TextAlign == TextAlign.Right) RenderLabel(writer, cb.ClientID, cb.Text, cb.CssClass);
                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                using (System.IO.StringWriter sw = new System.IO.StringWriter(sb, System.Globalization.CultureInfo.InvariantCulture))
                {
                    using (HtmlTextWriter writerDummy = new HtmlTextWriter(sw))
                    {
                        base.Render(writerDummy);
                    }
                }
            }
            else
            {
                base.Render(writer);
            }

        }

        private static void RenderLabel(HtmlTextWriter writer, string inputId, string text, string cssClass)
        {
            if (!string.IsNullOrEmpty(text))
            {
                if (!string.IsNullOrEmpty(cssClass)) writer.AddAttribute(HtmlTextWriterAttribute.Class, cssClass);
                writer.AddAttribute(HtmlTextWriterAttribute.For, inputId);
                writer.RenderBeginTag(HtmlTextWriterTag.Label);
                writer.Write(text);
                writer.RenderEndTag();
            }
        }
    }
}
